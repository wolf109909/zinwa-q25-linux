from dbus_fast.service import ServiceInterface, method, dbus_property, signal
from dbus_fast.constants import PropertyAccess
from dbus_fast import Variant, DBusError

from ofono2mm.mm_call import MMCallInterface
from ofono2mm.logging import ofono2mm_print

call_i = 1

class MMModemVoiceInterface(ServiceInterface):
    def __init__(self, bus, ofono_client, modem_name, ofono_interfaces, ofono_interface_props, verbose=False):
        super().__init__('org.freedesktop.ModemManager1.Modem.Voice')
        self.modem_name = modem_name
        ofono2mm_print("Initializing Voice interface", verbose)
        self.bus = bus
        self.ofono_client = ofono_client
        self.ofono_interfaces = ofono_interfaces
        self.ofono_interface_props = ofono_interface_props
        self.verbose = verbose
        self.props = {
            'Calls': Variant('ao', []),
            'EmergencyOnly': Variant('b', False),
        }
        self.call_path_map = {}
        self.calls = {}

    def set_emergency_mode(self):
        prev = self.props['EmergencyOnly'].value
        val = False
        try:
            if 'org.ofono.SimManager' in self.ofono_interface_props:
                sim_props = self.ofono_interface_props['org.ofono.SimManager']
                if 'FixedDialing' in sim_props.props:
                    val = bool(sim_props['FixedDialing'].value)
        except Exception as e:
            ofono2mm_print(f"Failed to check emergency state, defaulting to False: {e}", self.verbose)
            val = False

        if val != prev:
            self.props['EmergencyOnly'] = Variant('b', val)
            self.emit_properties_changed({'EmergencyOnly': val})

    def init_calls(self):
        ofono2mm_print("Initializing signals", self.verbose)

        self.set_emergency_mode()

        if 'org.ofono.VoiceCallManager' in self.ofono_interfaces:
            self.ofono_interfaces['org.ofono.VoiceCallManager'].on_call_added(self.add_call)
            self.ofono_interfaces['org.ofono.VoiceCallManager'].on_call_removed(self.remove_call)
        else:
            ofono2mm_print("org.ofono.VoiceCallManager was not available when initializing call", self.verbose)

    def clean_phone_number(self, number):
        # Remove any *31#, #31#, or similar prefixes
        while number.startswith('*') or number.startswith('#'):
            number = number.split('#', 1)[-1]
        return number

    def add_call(self, path, props):
        ofono2mm_print(f"Add call with object path {path} and properties {props}", self.verbose)

        global call_i

        if path in self.call_path_map:
            ofono2mm_print(f"Call with oFono path {path} already exists", self.verbose)
            return

        self.set_emergency_mode()

        state = props.get('State', Variant('s', '')).value
        line_identification = props.get('LineIdentification', Variant('s', '')).value
        multiparty = props.get('Multiparty', Variant('b', False))

        object_path = f'/org/freedesktop/ModemManager1/Call/{call_i}'
        if state == 'incoming':
            mm_call_interface = MMCallInterface(self.ofono_client, self.ofono_interfaces, self.verbose)
            mm_call_interface.props.update({
                'State': Variant('i', 3), # ringing in MM_CALL_STATE_RINGING_IN
                'StateReason': Variant('i', 2), # incoming new MM_CALL_STATE_REASON_INCOMING_NEW
                'Direction': Variant('i', 1), # incoming MM_CALL_DIRECTION_INCOMING
                'Number': Variant('s', line_identification),
                'Multiparty': multiparty,
            })

            mm_call_interface.voicecall = path
            mm_call_interface.init_call()

            self.bus.export(object_path, mm_call_interface)
            self.calls[object_path] = mm_call_interface
            self.props['Calls'].value.append(object_path)
            self.call_path_map[path] = object_path
            self.emit_properties_changed({'Calls': self.props['Calls'].value})
            self.CallAdded(object_path)
            call_i += 1
        elif state == 'dialing':
            mm_call_interface = MMCallInterface(self.ofono_client, self.ofono_interfaces, self.verbose)
            mm_call_interface.props.update({
                'State': Variant('i', 2),  # ringing out MM_CALL_STATE_RINGING_OUT
                'StateReason': Variant('i', 0), # unknown MM_CALL_STATE_REASON_UNKNOWN
                'Direction': Variant('i', 2), # outgoing MM_CALL_DIRECTION_OUTGOING
                'Number': Variant('s', line_identification),
            })

            mm_call_interface.voicecall = path
            mm_call_interface.init_call()

            self.bus.export(object_path, mm_call_interface)
            self.calls[object_path] = mm_call_interface
            self.props['Calls'].value.append(object_path)
            self.call_path_map[path] = object_path
            self.emit_properties_changed({'Calls': self.props['Calls'].value})
            self.CallAdded(object_path)
            call_i += 1
        elif state == 'alerting':
            cleaned_number = self.clean_phone_number(line_identification)
            mm_call_interface = MMCallInterface(self.ofono_client, self.ofono_interfaces, self.verbose)
            mm_call_interface.props.update({
                'State': Variant('i', 2), # ringing out MM_CALL_STATE_RINGING_OUT
                'StateReason': Variant('i', 1), # outgoing started MM_CALL_STATE_REASON_OUTGOING_STARTED
                'Direction': Variant('i', 2), # outgoing MM_CALL_DIRECTION_OUTGOING
                'Number': Variant('s', cleaned_number),
                'Multiparty': multiparty,
            })

            mm_call_interface.voicecall = path
            mm_call_interface.init_call()

            self.bus.export(object_path, mm_call_interface)
            self.calls[object_path] = mm_call_interface
            self.props['Calls'].value.append(object_path)
            self.call_path_map[path] = object_path
            self.emit_properties_changed({'Calls': self.props['Calls'].value})
            self.CallAdded(object_path)
            call_i += 1

    def remove_call(self, path):
        ofono2mm_print(f"Remove call with object path {path}", self.verbose)

        try:
            mm_path = self.call_path_map[path]
            self.props['Calls'].value.remove(mm_path)
            self.bus.unexport(mm_path)
            self.calls.pop(mm_path, None)
            del self.call_path_map[path]
            self.emit_properties_changed({'Calls': self.props['Calls'].value})
            self.CallDeleted(mm_path)
        except KeyError:
            ofono2mm_print(f"No mapping found for ofono path {path}", self.verbose)
        except Exception as e:
            ofono2mm_print(f"Error while removing call {path}: {e}", self.verbose)

        self.set_emergency_mode()

    @method()
    def ListCalls(self) -> 'ao':
        ofono2mm_print("Returning list of calls", self.verbose)
        return self.props['Calls'].value

    @method()
    async def DeleteCall(self, path: 'o'):
        ofono2mm_print(f"Deleting call with object path {path}", self.verbose)

        if path in self.props['Calls'].value:
            if 'org.ofono.VoiceCallManager' not in self.ofono_interfaces:
                raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'VoiceCallManager is not available')

            await self.ofono_interfaces['org.ofono.VoiceCallManager'].call_hangup_all()
            self.props['Calls'].value.remove(path)
            ofono_path = next((k for k, v in self.call_path_map.items() if v == path), None)
            if ofono_path:
                del self.call_path_map[ofono_path]
            self.bus.unexport(path)
            self.calls.pop(path, None)
            self.emit_properties_changed({'Calls': self.props['Calls'].value})
            self.CallDeleted(path)

        self.set_emergency_mode()

    @method()
    async def CreateCall(self, properties: 'a{sv}') -> 'o':
        ofono2mm_print(f"Creating call with properties {properties}", self.verbose)

        global call_i

        if 'number' not in properties:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.InvalidArgs', "Property 'number' is required")

        if 'org.ofono.VoiceCallManager' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'VoiceCallManager is not available')

        self.set_emergency_mode()

        object_path = f'/org/freedesktop/ModemManager1/Call/{call_i}'
        number = properties['number'].value

        try:
            path = await self.ofono_interfaces['org.ofono.VoiceCallManager'].call_dial(number, "")
        except Exception as e:
            ofono2mm_print(f"Failed to dial: {e}", self.verbose)
            return object_path # CallAdded should take care of the rest on false failures? kind of a hack but it works ¯\_(ツ)_/¯

        mm_call_interface = MMCallInterface(self.ofono_client, self.ofono_interfaces, self.verbose)
        mm_call_interface.props.update({
            'State': Variant('i', 2), # ringing out MM_CALL_STATE_RINGING_OUT
            'StateReason': Variant('i', 1), # outgoing started MM_CALL_STATE_REASON_OUTGOING_STARTED
            'Direction': Variant('i', 2), # outgoing MM_CALL_DIRECTION_OUTGOING
            'Number': Variant('s', number),
        })

        mm_call_interface.voicecall = path
        mm_call_interface.init_call()

        self.bus.export(object_path, mm_call_interface)
        self.calls[object_path] = mm_call_interface
        self.props['Calls'].value.append(object_path)
        self.call_path_map[path] = object_path
        self.emit_properties_changed({'Calls': self.props['Calls'].value})
        self.CallAdded(object_path)
        call_i += 1

        return object_path

    @method()
    async def HoldAndAccept(self):
        ofono2mm_print("Holding and accepting call", self.verbose)
        if 'org.ofono.VoiceCallManager' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'VoiceCallManager is not available')
        await self.ofono_interfaces['org.ofono.VoiceCallManager'].call_hold_and_answer()

    @method()
    async def HangupAndAccept(self):
        ofono2mm_print("Hanging up and accepting call", self.verbose)
        if 'org.ofono.VoiceCallManager' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'VoiceCallManager is not available')
        await self.ofono_interfaces['org.ofono.VoiceCallManager'].call_release_and_answer()

    @method()
    async def HangupAll(self):
        ofono2mm_print("Hanging up all calls", self.verbose)
        if 'org.ofono.VoiceCallManager' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'VoiceCallManager is not available')
        await self.ofono_interfaces['org.ofono.VoiceCallManager'].call_hangup_all()

    @method()
    async def Transfer(self):
        ofono2mm_print("Transferring call", self.verbose)
        if 'org.ofono.VoiceCallManager' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'VoiceCallManager is not available')
        await self.ofono_interfaces['org.ofono.VoiceCallManager'].call_transfer()

    @method()
    async def CallWaitingSetup(self, enable: 'b'):
        ofono2mm_print(f"Activate call waiting network: {enable}", self.verbose)
        if 'org.ofono.CallSettings' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'CallSettings is not available')
        status = 'enabled' if enable else 'disabled'
        await self.ofono_interfaces['org.ofono.CallSettings'].call_set_property('VoiceCallWaiting', Variant('s', status))

    @method()
    async def CallWaitingQuery(self) -> 'b':
        ofono2mm_print("Query the status of call waiting network", self.verbose)

        if 'org.ofono.CallSettings' not in self.ofono_interfaces:
            raise DBusError('org.freedesktop.ModemManager1.Error.Core.WrongState', 'CallSettings is not available')

        enabled = False
        props = await self.ofono_interfaces['org.ofono.CallSettings'].call_get_properties()
        if 'VoiceCallWaiting' in props:
            status = props['VoiceCallWaiting'].value
            ofono2mm_print(f"Call waiting is {status}", self.verbose)
            if status == "enabled":
                enabled = True
        else:
            ofono2mm_print(f"VoiceCallWaiting is not available in org.ofono.CallSettings properties: {props}", self.verbose)
        return enabled

    @signal()
    def CallAdded(self, path) -> 'o':
        ofono2mm_print(f"Signal: Call added with object path {path}", self.verbose)
        return path

    @signal()
    def CallDeleted(self, path) -> 'o':
        ofono2mm_print(f"Signal: Call deleted with object path {path}", self.verbose)
        return path

    @dbus_property(access=PropertyAccess.READ)
    def Calls(self) -> 'ao':
        return self.props['Calls'].value

    @dbus_property(access=PropertyAccess.READ)
    def EmergencyOnly(self) -> 'b':
        return self.props['EmergencyOnly'].value
