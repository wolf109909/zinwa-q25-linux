import asyncio
from os import makedirs
from os.path import join, exists

settings_dir = '/var/lib/ofono2mm'
settings_file = join(settings_dir, 'settings.conf')

def async_retryable(times=0):
    """
    Decorator that allows to retry the given function n times.

    Usage:

    @async_retryable(5)
    async def fail():
        raise Exception("This function will be tried five times!")

    If times is 0 (default), the function will be retried indefinitely.
    """

    def decorator(func):
            async def wrapper(*args, **kwargs):
                    current_try = 0
                    while times == 0 or current_try < times:
                            try:
                                    result = await func(*args, **kwargs)
                            except Exception:
                                    if current_try == times-1:
                                            raise

                                    # print("Trying again, error was %s" % e)
                                    await asyncio.sleep(5)

                                    current_try += 1
                            else:
                                    return result

            return wrapper

    return decorator

def save_setting(key, value):
    makedirs(settings_dir, exist_ok=True)

    settings = parse_settings()

    settings[key] = value

    with open(settings_file, 'w', encoding='utf-8') as file:
        for k, v in settings.items():
            file.write(f"{k}: {v}\n")

def read_setting(key, default=False):
    settings = parse_settings()
    return str(settings.get(key, default))

def parse_settings():
    settings = {}
    if exists(settings_file):
        with open(settings_file, 'r', encoding='utf-8') as file:
            for line in file:
                if ':' in line:
                    k, v = line.strip().split(':', 1)
                    settings[k] = v.strip()
    return settings

def netmask_to_prefix(netmask):
    """
    Convert a dotted-quad IPv4 netmask to a prefix length.

    oFono reports the netmask, while ModemManager's Ip4Config expects a
    prefix - and a missing or zero prefix makes NetworkManager fall back to
    a guessed classful value, which puts the address on the wrong-sized
    network.
    """
    try:
        return sum(bin(int(octet)).count('1') for octet in netmask.split('.'))
    except (AttributeError, ValueError):
        return 0
